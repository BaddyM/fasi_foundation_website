<?php $__env->startSection('title'); ?>
    Fasi | Collage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <nav class="breadcrumb mt-2">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active" aria-current="page">Collage</span>
    </nav>

    <?php
        $images = [
            '1.JPG',
            '2.JPG',
            '3.JPG',
            '4.jpeg',
            '5.jpeg',
            '6.jpeg',
            '7.jpg',
            '8.jpeg',
            '9.jpeg',
            '10.jpeg',
            '11.jpeg',
        ];

        $images_others = [
            '1.jpg' => '',
            '2.jpg' => '',
            '3.jpg' => '',
            '4.jpg' => '',
            '5.jpg' => '',
            '6.jpg' => '',
            '7.jpg' => 'Outreach to offer assessment services to families of children living with disabilities',
            '8.jpg' => 'Outreach to offer assessment services to families of children living with disabilities',
            '9.jpg' => 'Outreach to offer assessment services to families of children living with disabilities',
            '10.jpg' => '',
            '11.jpg' => 'Outreach to offer assessment services to families of children living with disabilities',
            '13.jpg' => '',
            '14.jpg' => 'Training workshop for community resource persons',
            '15.jpg' => ' One-on-one counselling and psychosocial support services',
            '16.jpg' => 'Nutrition assessment of children under 5 years by VHTs during home visits',
            '19.jpg' => 'Nutrition assessment at integrated community outreaches',
            '20.jpg' => 'Integrated community outreaches',
            '21.jpg' => ' Use of relevant IEC materials at outreaches',
            '22.jpg' => 'Provision of nutrition assessment tools for household level nutrition and growth monitoring',
        ];
    ?>

    <div class="title" data-aos="flip-right" data-aos-duration=2000>
        <div></div>
        <p class="mb-0">Our Work</p>
        <div></div>
    </div>

    <div class="w-100 row my-3 align-items-center d-flex justify-content-center">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 my-4" data-aos="zoom-in" data-aos-duration=2000>
                <div class="card shadow">
                    <img class="img-fluid w-100 img-thumbnail"
                        src="<?php echo e(asset('assets/images/collage/thrive-ug/' . $img . '')); ?>" alt="">
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="w-100 row my-3 align-items-center d-flex justify-content-center">
        <?php $__currentLoopData = $images_others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 my-4" data-aos="zoom-in" data-aos-duration=2000>
                <div class="card shadow">
                    <img class="img-fluid w-100 img-thumbnail" src="<?php echo e(asset('assets/images/collage/' . $key . '')); ?>"
                        alt="">
                    <?php if($value != null): ?>
                        <div class="card-footer">
                            <p class="mb-0"><?php echo e($value); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baddy/mysites/fasi_foundation/resources/views/collage.blade.php ENDPATH**/ ?>