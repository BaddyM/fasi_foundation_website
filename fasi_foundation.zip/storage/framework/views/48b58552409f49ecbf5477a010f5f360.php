<?php $__env->startSection('title'); ?>
    Fasi | Opportunities
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <nav class="breadcrumb mt-2">
        <a class="breadcrumb-item" href="<?php echo e(route("home")); ?>">Home</a>
        <span class="breadcrumb-item active" aria-current="page">Opportunities</span>
    </nav>

    <div class="container">
        <div class="alert alert-warning p-2">
            <p class="mb-0">There aren't any opportunities yet, but as soon as they are available, we shall post them here. <br>
                Thank you.
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baddy/mysites/fasi_foundation/resources/views/jobs.blade.php ENDPATH**/ ?>