<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('fasi-logo.png')); ?>?v2" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/tiny_slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/aos/aos.css')); ?>">
</head>

<body>
    <div id="body" class="d-none">
        <div class="d-flex justify-content-center">
            <div class="top_header p-1 shadow text-center">
                <div class="row justify-content-between align-items-center">
                    <div class="col-md-6 row">
                        <div class="d-flex align-items-center col-md-5" style="gap:10px;">
                            <i class="fa fa-envelope"></i>
                            <p class="mb-0">info@fasifoundationug.org</p>
                        </div>
                        <div class="d-flex align-items-center col-md-5" style="gap:10px;">
                            <i class="fa fa-phone"></i>
                            <p class="mb-0">+256704842321</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a class="btn bg-white rounded-5" href="Use: https://wa.me/0704842321"><i class="bi bi-whatsapp"></i></a>
                        <a class="btn bg-white rounded-5" style="color: blue;"><i class="bi bi-facebook"></i></a>
                        <a class="btn bg-white rounded-5" style="color:rgb(252, 155, 171);"><i
                                class="bi bi-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-center logo my-3">
            <div>
                <img src="<?php echo e(asset('fasi-logo.png')); ?>" alt="">
            </div>
            <p class="mb-0">Fasi Foundation</p>
        </div>

        <nav class="navbar navbar-expand-sm navbar-dark bg-primary w-100">
            <a class="navbar-brand fw-bold text-warning" href="<?php echo e(route('home')); ?>">FasiFoundation</a>
            <button class="navbar-toggler d-lg-none text-white" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fa fa-list"></i>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>" aria-current="page"><i class="fa fa-house"></i>
                            Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('about')); ?>"><i class="fa fa-newspaper"></i> Who we are</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('collage')); ?>"><i class="fa fa-photo-film"></i> Collage</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jobs')); ?>"><i class="fa fa-user-doctor"></i> Careers</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"><i class="fa fa-phone"></i> Reach Us</a>
                    </li>
                </ul>
                <form id="search_form" class="d-flex my-2 my-lg-0">
                    <input class="form-control me-sm-2" type="text" placeholder="Search" />
                    <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">
                        Search
                    </button>
                </form>
            </div>
        </nav>

        <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('body'); ?>

        <footer class="mt-5">
            <div class="row justify-content-between w-100">
                <div class="col-md-1 text-center mb-3">
                    <img src="<?php echo e(asset('fasi-logo.png')); ?>" alt="">
                    <p class="mb-0 text-white fw-bold">Fasi Foundation</p>
                </div>
                <div class="col-md-2 text-white mb-3">
                    <p class="mb-2 text-center fw-bold text-decoration-underline">Useful links</p>
                    <a class="nav-link my-2" href="<?php echo e(route('home')); ?>" aria-current="page"><i
                            class="fa fa-house"></i>
                        Home</a>
                    <a class="nav-link my-2" href="<?php echo e(route('about')); ?>"><i class="fa fa-newspaper"></i> Who we
                        are</a>
                    <a class="nav-link my-2" href="<?php echo e(route('collage')); ?>"><i class="fa fa-photo-film"></i>
                        Collage</a>
                    <a class="nav-link my-2" href="<?php echo e(route('jobs')); ?>"><i class="fa fa-user-doctor"></i>
                        Careers</a>
                    <a class="nav-link my-2" href="<?php echo e(route('contact')); ?>"><i class="fa fa-phone"></i> Reach Us</a>
                </div>
                <div class="col-md-2 text-center">
                    <p class="mb-2 text-white fw-bold text-decoration-underline">Our Socials</p>
                    <div>
                        <a class="btn bg-white rounded-5" href="Use: https://wa.me/0704842321"><i class="bi bi-whatsapp"></i></a>
                        <a class="btn bg-white rounded-5" style="color: blue;"><i class="bi bi-facebook"></i></a>
                        <a class="btn bg-white rounded-5" style="color:rgb(252, 155, 171);"><i
                                class="bi bi-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <p class="my-2 text-white">
                    <?php
                        $year = date("Y",strtotime(now()));
                    ?>
                    Copyright <?php echo e($year); ?> <i class="bi bi-c-circle"></i> fasifoundationug
                </p>
            </div>
        </footer>
    </div>

    <div class="page_loader" id="page_loader">
        <img class="img-fluid" src="<?php echo e(asset('assets/images/loader/loading.gif')); ?>" alt="">
    </div>

    <script src="<?php echo e(asset('assets/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/tiny_slider.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/aos/aos.js')); ?>"></script>
    <script>
        AOS.init();
    </script>
    <script>
        $(window).on("load", function() {
            $("#page_loader").addClass("d-none");
            $("#body").removeClass("d-none");
        });

        $(document).ready(function() {
            $("#search_form").on("submit", function(e) {
                e.preventDefault();
                $(this)[0].reset();
                $("#alert_modal").modal("show");
                $("#alert_body").text("No Results Found!");
                setTimeout(() => {
                    $("#alert_modal").modal("hide");
                }, 3000);
            })
        })
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/baddy/mysites/fasi_foundation/resources/views/common.blade.php ENDPATH**/ ?>