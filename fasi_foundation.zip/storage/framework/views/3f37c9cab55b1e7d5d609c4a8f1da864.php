<?php $__env->startSection('title'); ?>
    Fasi | Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="images-slider container-fluid">
        <div>
            <img class="img-fluid" src="<?php echo e(asset('assets/images/collage/1.jpg')); ?>" alt="">
        </div>
        <div>
            <img class="img-fluid" src="<?php echo e(asset('assets/images/collage/2.jpg')); ?>" alt="">
        </div>
        <div>
            <img class="img-fluid" src="<?php echo e(asset('assets/images/collage/3.jpg')); ?>" alt="">
        </div>
        <div>
            <img class="img-fluid" src="<?php echo e(asset('assets/images/collage/4.jpg')); ?>" alt="">
        </div>
    </div>

    <div class="container my-3">
        <div class="title" data-aos="flip-right" data-aos-duration=2000>
            <div></div>
            <p class="mb-0">On Going Projects</p>
            <div></div>
        </div>

        <p data-aos="flip-left" data-aos-duration=2000>
            <strong class="fst-italic">Thrive Ug</strong> is a child health venture being piloted with support from D-Prize
            under the alias Taasa-Abato Health
            link, with a vision to contribute to community health systems strengthening by improving the community-facility
            linkages. Our mission is to optimize child health in Uganda’s marginalized communities by facilitating the
            improved uptake and utilization of available health services.
            The 3 months pilot was launched in September 2024 in the slum communities of Rubaga division, aiming to link
            between 300-500 children to health facilities so they can receive their immunizations which would otherwise not
            occur. Afterwards, we hope to spend the following 21 months cascading to the rest of the divisions in Kampala,
            so we end the first two years reaching at least 10,000 people.
            Our team unites a diverse group of public health, community outreach, and project management professionals, all
            dedicated to reducing health disparities and improving outcomes for underserved populations. Driven by our
            mission to create lasting impact, we leverage proven strategies, innovation, and deep expertise to deliver
            sustainable health improvements so we can reduce vaccine-preventable diseases, lower healthcare costs and
            financial strain on families, while enhancing productivity through fewer missed school and work days. Our
            efforts will empower parents and caregivers with essential vaccine knowledge, fostering a positive shift toward
            healthier practices and long-term social change. <br>
        </p>

        <div class="text-center">
            <strong class="text-primary text-decoration-underline h5 fw-bold">Pictorial</strong>
        </div>

        <?php
            $images = [
                '1.JPG',
                '2.JPG',
                '3.JPG',
                '4.jpeg',
                '5.jpeg',
                '6.jpeg',
                '7.jpg',
                '8.jpeg',
                '9.jpeg',
                '10.jpeg',
                '11.jpeg',
            ];
        ?>

        <div class="w-100 row my-3 align-items-center d-flex justify-content-center">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 my-4" data-aos="zoom-in" data-aos-duration=2000>
                    <div class="card shadow">
                        <img class="img-fluid w-100 img-thumbnail"
                            src="<?php echo e(asset('assets/images/collage/thrive-ug/' . $img . '')); ?>" alt="">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="title" data-aos="fade-right" data-aos-duration=2000>
            <div></div>
            <p class="mb-0">Be a member</p>
            <div></div>
        </div>

        <div class="row donation_volunteer mb-3" data-aos="fade-left" data-aos-duration=2000>
            <div class="col-md-3">
                <div class="card border-0 shadow">
                    <div class="card-header">
                        <p class="mb-0 fw-bold text-center">Become a Volunteer</p>
                    </div>
                    <img class="img-fluid"
                        src="<?php echo e(asset('assets/images/static/people-volunteering-donating-money_53876-66112.avif')); ?>"
                        alt="">
                    <div class="card-body">
                        <button type="button" id="volunteer_btn"
                            class="btn btn-warning fw-bold bg-gradient">Register</button>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card border-0 shadow">
                    <div class="card-header">
                        <p class="mb-0 fw-bold text-center">Donate</p>
                    </div>
                    <img class="img-fluid" src="<?php echo e(asset('assets/images/static/make-a-donation-02.png')); ?>" alt="">
                    <div class="card-body">
                        <button type="button" id="donate_btn" class="btn btn-success fw-bold bg-gradient">Donate</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="donation_modal" tabindex="-1" data-bs-keyboard="false" role="dialog">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Donate to Fasi Foundation <i class="fa fa-circle-plus"></i>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="fw-bold text-danger">Coming Soon!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="volunteer_modal" tabindex="-1" data-bs-keyboard="false" role="dialog">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Register to be a volunteer <i class="fa fa-circle-plus"></i>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="volunteer_registrationg_form" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2 form-floating">
                            <input type="text" name="name" placeholder="Add Full Name" class="form-control" required>
                            <label>Full Name <strong class="text-danger">*</strong></label>
                        </div>
                        <div class="mb-2 form-floating">
                            <input type="text" name="name" placeholder="Add Full Name" class="form-control" required>
                            <label>Email or Phone Number <strong class="text-danger">*</strong></label>
                        </div>
                        <button class="btn btn-warning px-4 fw-bold bg-gradient mt-3" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(window).on("load", function() {
            var slider = tns({
                container: '.images-slider',
                items: 3,
                slideBy: 'page',
                autoplay: true,
                controls: false,
                nav: false,
                touch: true
            });
        });

        $(document).ready(function() {
            $("#donate_btn").on("click", function() {
                $("#donation_modal").modal("show");
                setTimeout(() => {
                    $("#donation_modal").modal("hide");
                }, 3000);
            });

            $("#volunteer_btn").on("click", function() {
                $("#volunteer_modal").modal("show");
            });

            $("#volunteer_registrationg_form").on("submit", function(e) {
                e.preventDefault();
                $("#volunteer_modal").modal("hide");
                $("#alert_modal").modal("show");
                $("#alert_body").text("Registration successfully, we shall ge back to you shortly!");
                setTimeout(() => {
                    $("#alert_modal").modal("hide");
                }, 3000);
            });

            $("#volunteer_modal").on("hidden.bs.modal", function() {
                $("#volunteer_registrationg_form")[0].reset();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baddy/mysites/fasi_foundation/resources/views/home.blade.php ENDPATH**/ ?>